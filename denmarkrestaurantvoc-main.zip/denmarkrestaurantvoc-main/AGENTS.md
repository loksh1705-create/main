<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

# Project rules

- Order prices are computed by the `price_order` DB trigger from `menu_items`; never trust client totals (prevents price tampering).
- The first account ever created becomes the sole admin via a trigger on signup; menu edits and order reads are gated by `has_role` RLS.
- Owner dashboard (/admin) is client-only and gets new orders via Realtime on `orders`.
