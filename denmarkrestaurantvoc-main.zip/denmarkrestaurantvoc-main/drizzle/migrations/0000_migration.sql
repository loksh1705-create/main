CREATE TYPE public.app_role AS ENUM ('admin');

CREATE TABLE public.user_roles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  role public.app_role NOT NULL,
  UNIQUE (user_id, role)
);
GRANT SELECT ON public.user_roles TO authenticated;
GRANT ALL ON public.user_roles TO service_role;
ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;
CREATE POLICY "own roles readable" ON public.user_roles FOR SELECT TO authenticated USING (auth.uid() = user_id);

CREATE OR REPLACE FUNCTION public.has_role(_user_id uuid, _role public.app_role)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (SELECT 1 FROM public.user_roles WHERE user_id = _user_id AND role = _role)
$$;

-- First account ever created becomes the owner (admin)
CREATE OR REPLACE FUNCTION public.handle_first_admin()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM public.user_roles WHERE role = 'admin') THEN
    INSERT INTO public.user_roles (user_id, role) VALUES (NEW.id, 'admin');
  END IF;
  RETURN NEW;
END $$;
CREATE TRIGGER on_auth_user_created_admin AFTER INSERT ON auth.users
FOR EACH ROW EXECUTE FUNCTION public.handle_first_admin();

CREATE TABLE public.menu_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  category text NOT NULL,
  price numeric(10,2) NOT NULL CHECK (price >= 0),
  description text,
  available boolean NOT NULL DEFAULT true,
  sort_order int NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.menu_items TO anon, authenticated;
GRANT INSERT, UPDATE, DELETE ON public.menu_items TO authenticated;
GRANT ALL ON public.menu_items TO service_role;
ALTER TABLE public.menu_items ENABLE ROW LEVEL SECURITY;
CREATE POLICY "menu public read" ON public.menu_items FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "admin insert menu" ON public.menu_items FOR INSERT TO authenticated WITH CHECK (public.has_role(auth.uid(), 'admin'));
CREATE POLICY "admin update menu" ON public.menu_items FOR UPDATE TO authenticated USING (public.has_role(auth.uid(), 'admin'));
CREATE POLICY "admin delete menu" ON public.menu_items FOR DELETE TO authenticated USING (public.has_role(auth.uid(), 'admin'));

CREATE TABLE public.orders (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  order_number serial,
  customer_name text NOT NULL CHECK (char_length(customer_name) BETWEEN 1 AND 100),
  phone text NOT NULL CHECK (char_length(phone) BETWEEN 6 AND 20),
  address text CHECK (address IS NULL OR char_length(address) <= 500),
  notes text CHECK (notes IS NULL OR char_length(notes) <= 500),
  order_type text NOT NULL CHECK (order_type IN ('dine_in','delivery')),
  items jsonb NOT NULL,
  total numeric(10,2) NOT NULL DEFAULT 0,
  status text NOT NULL DEFAULT 'new' CHECK (status IN ('new','preparing','completed','cancelled')),
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT INSERT ON public.orders TO anon, authenticated;
GRANT SELECT, UPDATE, DELETE ON public.orders TO authenticated;
GRANT USAGE ON SEQUENCE public.orders_order_number_seq TO anon, authenticated;
GRANT ALL ON public.orders TO service_role;
ALTER TABLE public.orders ENABLE ROW LEVEL SECURITY;
CREATE POLICY "anyone can place order" ON public.orders FOR INSERT TO anon, authenticated WITH CHECK (status = 'new');
CREATE POLICY "admin read orders" ON public.orders FOR SELECT TO authenticated USING (public.has_role(auth.uid(), 'admin'));
CREATE POLICY "admin update orders" ON public.orders FOR UPDATE TO authenticated USING (public.has_role(auth.uid(), 'admin'));
CREATE POLICY "admin delete orders" ON public.orders FOR DELETE TO authenticated USING (public.has_role(auth.uid(), 'admin'));

-- Server-side pricing: items come in as [{id, qty}], rebuilt from the real menu
CREATE OR REPLACE FUNCTION public.price_order()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE built jsonb; tot numeric;
BEGIN
  IF jsonb_typeof(NEW.items) <> 'array' OR jsonb_array_length(NEW.items) = 0 THEN
    RAISE EXCEPTION 'Order must contain items';
  END IF;
  SELECT jsonb_agg(jsonb_build_object('id', m.id, 'name', m.name, 'price', m.price, 'qty', q.qty)),
         sum(m.price * q.qty)
    INTO built, tot
  FROM (SELECT (e->>'id')::uuid AS id, LEAST(GREATEST((e->>'qty')::int,1),50) AS qty
        FROM jsonb_array_elements(NEW.items) e) q
  JOIN public.menu_items m ON m.id = q.id AND m.available;
  IF built IS NULL THEN RAISE EXCEPTION 'No valid items'; END IF;
  IF NEW.order_type = 'delivery' AND coalesce(trim(NEW.address),'') = '' THEN
    RAISE EXCEPTION 'Delivery address required';
  END IF;
  NEW.items := built; NEW.total := tot; NEW.status := 'new';
  RETURN NEW;
END $$;
CREATE TRIGGER orders_price BEFORE INSERT ON public.orders FOR EACH ROW EXECUTE FUNCTION public.price_order();

ALTER PUBLICATION supabase_realtime ADD TABLE public.orders;

INSERT INTO public.menu_items (category, name, price, sort_order) VALUES
('Chicken Starters','Chicken 65',180,1),('Chicken Starters','Pepper Chicken Fry',200,2),('Chicken Starters','Chicken Lollipop',220,3),('Chicken Starters','Chilli Chicken Dry',210,4),('Chicken Starters','Dragon Chicken',230,5),('Chicken Starters','Crispy Fried Chicken',190,6),('Chicken Starters','Chicken Manchurian Dry',210,7),('Chicken Starters','Garlic Chicken',220,8),('Chicken Starters','Chettinad Chicken Fry',230,9),('Chicken Starters','Kung Pao Chicken',240,10),
('Mutton Specials','Mutton Chukka',320,1),('Mutton Specials','Mutton Pepper Fry',330,2),('Mutton Specials','Mutton Kola Urundai',280,3),('Mutton Specials','Mutton Brain Fry',300,4),('Mutton Specials','Mutton Liver Fry',260,5),('Mutton Specials','Mutton Chettinad Gravy',340,6),('Mutton Specials','Mutton Paya',300,7),('Mutton Specials','Mutton Keema Masala',310,8),
('Seafood','Fish 65',240,1),('Seafood','Prawn Fry',320,2),('Seafood','Chilli Prawns',340,3),('Seafood','Nethili Fry',220,4),('Seafood','Vanjaram Fish Fry',380,5),('Seafood','Crab Masala',420,6),('Seafood','Squid Pepper Fry',300,7),('Seafood','Golden Fried Prawns',350,8),('Seafood','Fish Manchurian',260,9),('Seafood','Meen Kuzhambu',260,10),
('Arabian Grill','Chicken Shawarma Roll',120,1),('Arabian Grill','Chicken Shawarma Plate',180,2),('Arabian Grill','Alfaham Chicken Full',480,3),('Arabian Grill','Alfaham Chicken Half',260,4),('Arabian Grill','Grilled Chicken Full',450,5),('Arabian Grill','Grilled Chicken Half',240,6),('Arabian Grill','Chicken Shish Tawook',280,7),('Arabian Grill','Mutton Seekh Kebab',320,8),('Arabian Grill','Chicken Tikka',260,9),('Arabian Grill','Peri Peri Chicken',280,10),('Arabian Grill','Mixed Grill Platter',650,11),('Arabian Grill','Beef-free Kofta Kebab',300,12),
('Mandi & Kabsa','Chicken Mandi Single',280,1),('Mandi & Kabsa','Chicken Mandi Family',950,2),('Mandi & Kabsa','Mutton Mandi Single',420,3),('Mandi & Kabsa','Mutton Mandi Family',1450,4),('Mandi & Kabsa','Fish Mandi',380,5),('Mandi & Kabsa','Chicken Kabsa',300,6),('Mandi & Kabsa','Mutton Kabsa',440,7),('Mandi & Kabsa','Alfaham Mandi',340,8),
('Biryani','Chicken Dum Biryani',220,1),('Biryani','Mutton Biryani',320,2),('Biryani','Ambur Chicken Biryani',230,3),('Biryani','Dindigul Mutton Biryani',340,4),('Biryani','Prawn Biryani',330,5),('Biryani','Fish Biryani',300,6),('Biryani','Egg Biryani',160,7),('Biryani','Chicken 65 Biryani',250,8),
('Chinese Rice & Noodles','Chicken Fried Rice',180,1),('Chinese Rice & Noodles','Egg Fried Rice',150,2),('Chinese Rice & Noodles','Mixed Meat Fried Rice',240,3),('Chinese Rice & Noodles','Schezwan Chicken Fried Rice',200,4),('Chinese Rice & Noodles','Prawn Fried Rice',240,5),('Chinese Rice & Noodles','Chicken Hakka Noodles',180,6),('Chinese Rice & Noodles','Schezwan Chicken Noodles',200,7),('Chinese Rice & Noodles','Egg Noodles',150,8),('Chinese Rice & Noodles','Mixed Meat Noodles',240,9),('Chinese Rice & Noodles','Chicken Triple Schezwan Rice',260,10),('Chinese Rice & Noodles','Chicken Chopsuey',250,11),('Chinese Rice & Noodles','Prawn Noodles',240,12),
('Chinese Gravies','Chilli Chicken Gravy',220,1),('Chinese Gravies','Chicken Manchurian Gravy',220,2),('Chinese Gravies','Hot Garlic Chicken',230,3),('Chinese Gravies','Chicken in Oyster Sauce',240,4),('Chinese Gravies','Chilli Fish Gravy',260,5),('Chinese Gravies','Prawn Schezwan Gravy',320,6),('Chinese Gravies','Lemon Chicken',230,7),('Chinese Gravies','Sweet & Sour Chicken',230,8),
('Soups','Chicken Hot & Sour Soup',120,1),('Soups','Chicken Manchow Soup',120,2),('Soups','Chicken Sweet Corn Soup',110,3),('Soups','Mutton Paya Soup',150,4),('Soups','Chicken Clear Soup',100,5),('Soups','Seafood Soup',160,6),
('Breads','Kuboos',20,1),('Breads','Parotta',25,2),('Breads','Kothu Parotta Chicken',180,3),('Breads','Egg Kothu Parotta',150,4),('Breads','Butter Naan',50,5),('Breads','Garlic Naan',60,6),('Breads','Ceylon Parotta',70,7),('Breads','Mutton Kothu Parotta',240,8),
('Beverages','Fresh Lime Soda',60,1),('Beverages','Mint Mojito',90,2),('Beverages','Arabian Lemon Mint',90,3),('Beverages','Sulaimani Tea',30,4),('Beverages','Mango Lassi',90,5),('Beverages','Rose Milk',70,6),('Beverages','Avocado Shake',140,7),
('Desserts','Kunafa',220,1),('Desserts','Umm Ali',180,2),('Desserts','Gulab Jamun',80,3),('Desserts','Darsaan with Ice Cream',150,4),('Desserts','Falooda',150,5),('Desserts','Elaneer Payasam',120,6);
