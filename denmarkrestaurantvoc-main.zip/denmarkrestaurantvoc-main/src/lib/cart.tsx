import { createContext, useContext, useEffect, useMemo, useState, type ReactNode } from "react";

export type CartLine = { id: string; name: string; price: number; qty: number };

type CartCtx = {
  lines: CartLine[];
  add: (item: Omit<CartLine, "qty">) => void;
  setQty: (id: string, qty: number) => void;
  clear: () => void;
  total: number;
  count: number;
};

const Ctx = createContext<CartCtx | null>(null);
const KEY = "denmark-cart";

export function CartProvider({ children }: { children: ReactNode }) {
  const [lines, setLines] = useState<CartLine[]>([]);

  useEffect(() => {
    try {
      const raw = localStorage.getItem(KEY);
      if (raw) setLines(JSON.parse(raw));
    } catch {}
  }, []);
  useEffect(() => {
    localStorage.setItem(KEY, JSON.stringify(lines));
  }, [lines]);

  const value = useMemo<CartCtx>(() => {
    const add: CartCtx["add"] = (item) =>
      setLines((prev) => {
        const ex = prev.find((l) => l.id === item.id);
        if (ex) return prev.map((l) => (l.id === item.id ? { ...l, qty: l.qty + 1 } : l));
        return [...prev, { ...item, qty: 1 }];
      });
    const setQty: CartCtx["setQty"] = (id, qty) =>
      setLines((prev) =>
        qty <= 0 ? prev.filter((l) => l.id !== id) : prev.map((l) => (l.id === id ? { ...l, qty } : l)),
      );
    return {
      lines,
      add,
      setQty,
      clear: () => setLines([]),
      total: lines.reduce((s, l) => s + l.price * l.qty, 0),
      count: lines.reduce((s, l) => s + l.qty, 0),
    };
  }, [lines]);

  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useCart() {
  const c = useContext(Ctx);
  if (!c) throw new Error("useCart outside CartProvider");
  return c;
}

export const inr = (n: number) => `₹${Number(n).toLocaleString("en-IN")}`;
