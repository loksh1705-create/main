import { createFileRoute, Link } from "@tanstack/react-router";
import { queryOptions, useSuspenseQuery } from "@tanstack/react-query";
import { useMemo, useState } from "react";
import { Minus, Plus, ShoppingBag, UtensilsCrossed, Bike, Flame } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { useCart, inr } from "@/lib/cart";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Sheet, SheetContent, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import hero from "@/assets/hero.jpg";
import grill from "@/assets/grill.jpg";
import wok from "@/assets/wok.jpg";

const menuQuery = queryOptions({
  queryKey: ["menu"],
  queryFn: async () => {
    const { data, error } = await supabase
      .from("menu_items")
      .select("id,name,category,price,description,available,sort_order")
      .order("category")
      .order("sort_order");
    if (error) throw error;
    return data;
  },
});

const CATEGORY_ORDER = [
  "Arabian Grill", "Mandi & Kabsa", "Chicken Starters", "Mutton Specials", "Seafood",
  "Biryani", "Chinese Rice & Noodles", "Chinese Gravies", "Soups", "Breads", "Beverages", "Desserts",
];

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Denmark Restaurant — Arabian & Chinese Non-Veg | Order Online" },
      { name: "description", content: "Order authentic Arabian mandi, shawarma, grills and Chinese non-veg dishes from Denmark Restaurant, Tamil Nadu. Dine in or delivery." },
      { property: "og:title", content: "Denmark Restaurant — Order Online" },
      { property: "og:description", content: "Authentic non-veg Arabian & Chinese food in Tamil Nadu. Dine in or delivery." },
    ],
  }),
  loader: ({ context }) => context.queryClient.ensureQueryData(menuQuery),
  component: Index,
});

function Index() {
  const { data: items } = useSuspenseQuery(menuQuery);
  const cart = useCart();
  const [open, setOpen] = useState(false);

  const grouped = useMemo(() => {
    const map = new Map<string, typeof items>();
    for (const it of items) {
      if (!map.has(it.category)) map.set(it.category, []);
      map.get(it.category)!.push(it);
    }
    const rank = (c: string) => { const i = CATEGORY_ORDER.indexOf(c); return i < 0 ? 999 : i; };
    return [...map.entries()].sort((a, b) => rank(a[0]) - rank(b[0]));
  }, [items]);

  const qtyOf = (id: string) => cart.lines.find((l) => l.id === id)?.qty ?? 0;

  return (
    <div className="min-h-screen">
      {/* Header */}
      <header className="fixed inset-x-0 top-0 z-40 border-b border-border/50 bg-background/80 backdrop-blur">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-4 py-3">
          <a href="#top" className="font-display text-lg tracking-[0.2em] text-primary">DENMARK</a>
          <nav className="flex items-center gap-2">
            <a href="#menu" className="hidden text-sm text-muted-foreground hover:text-foreground sm:block px-3">Menu</a>
            <Button onClick={() => setOpen(true)} className="gap-2">
              <ShoppingBag className="h-4 w-4" /> {cart.count > 0 ? `${cart.count} · ${inr(cart.total)}` : "Cart"}
            </Button>
          </nav>
        </div>
      </header>

      {/* Hero */}
      <section id="top" className="relative flex min-h-[92vh] items-end overflow-hidden">
        <img src={hero} alt="Arabian mandi, shawarma, chilli chicken and noodles" width={1920} height={1088} className="absolute inset-0 h-full w-full object-cover" />
        <div className="absolute inset-0 bg-hero-overlay" />
        <div className="relative mx-auto w-full max-w-6xl px-4 pb-20 pt-32">
          <p className="mb-4 text-sm uppercase tracking-[0.35em] text-primary">Arabian · Chinese · Tamil Nadu</p>
          <h1 className="font-display text-5xl leading-none sm:text-7xl md:text-8xl">DENMARK<br />RESTAURANT</h1>
          <p className="mt-6 max-w-xl text-lg text-muted-foreground">
            Authentic non-vegetarian feasts — charcoal grills, smoky mandi and fiery wok classics, cooked the way Tamil Nadu loves it.
          </p>
          <div className="mt-8 flex flex-wrap gap-3">
            <Button size="lg" asChild className="shadow-glow"><a href="#menu">Order now</a></Button>
            <Button size="lg" variant="outline" onClick={() => setOpen(true)}>View cart</Button>
          </div>
        </div>
      </section>

      {/* Highlights */}
      <section className="mx-auto grid max-w-6xl gap-6 px-4 py-16 md:grid-cols-2">
        {[{ img: grill, t: "From the Arabian grill", d: "Alfaham, shawarma, kebabs & mandi slow-cooked over charcoal." },
          { img: wok, t: "Fire of the wok", d: "Chilli chicken, schezwan noodles and Indo-Chinese favourites." }].map((c) => (
          <div key={c.t} className="group relative overflow-hidden rounded-xl">
            <img src={c.img} alt={c.t} loading="lazy" width={1024} height={768} className="h-72 w-full object-cover transition-transform duration-700 group-hover:scale-105" />
            <div className="absolute inset-0 bg-hero-overlay" />
            <div className="absolute bottom-0 p-6">
              <h3 className="font-display text-2xl">{c.t}</h3>
              <p className="text-sm text-muted-foreground">{c.d}</p>
            </div>
          </div>
        ))}
      </section>

      {/* Menu */}
      <section id="menu" className="ornament border-t border-border/50">
        <div className="mx-auto max-w-6xl px-4 py-16">
          <div className="mb-10 text-center">
            <Flame className="mx-auto mb-3 h-6 w-6 text-spice" />
            <h2 className="font-display text-4xl sm:text-5xl">Our Menu</h2>
            <p className="mt-2 text-muted-foreground">{items.length} dishes · tap + to add</p>
          </div>

          <div className="sticky top-[57px] z-30 -mx-4 mb-8 overflow-x-auto bg-background/90 px-4 py-3 backdrop-blur">
            <div className="flex gap-2">
              {grouped.map(([cat]) => (
                <a key={cat} href={`#cat-${slug(cat)}`} className="whitespace-nowrap rounded-full border border-border px-4 py-1.5 text-sm text-muted-foreground transition hover:border-primary hover:text-primary">
                  {cat}
                </a>
              ))}
            </div>
          </div>

          <div className="space-y-14">
            {grouped.map(([cat, list]) => (
              <div key={cat} id={`cat-${slug(cat)}`} className="scroll-mt-32">
                <h3 className="mb-5 font-display text-2xl text-primary">{cat}</h3>
                <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
                  {list.map((it) => {
                    const q = qtyOf(it.id);
                    return (
                      <div key={it.id} className={`flex items-center justify-between gap-3 rounded-lg border border-border bg-card p-4 transition ${q ? "border-primary/60" : ""} ${!it.available ? "opacity-50" : ""}`}>
                        <div className="min-w-0">
                          <p className="font-medium leading-tight">{it.name}</p>
                          <p className="mt-1 text-sm text-primary">{inr(it.price)}</p>
                          {!it.available && <p className="text-xs text-muted-foreground">Unavailable today</p>}
                        </div>
                        {it.available && (q === 0 ? (
                          <Button size="sm" variant="outline" onClick={() => { cart.add({ id: it.id, name: it.name, price: Number(it.price) }); }}>
                            <Plus className="h-4 w-4" /> Add
                          </Button>
                        ) : (
                          <div className="flex items-center gap-2">
                            <Button size="icon" variant="secondary" className="h-8 w-8" onClick={() => cart.setQty(it.id, q - 1)} aria-label="Remove one"><Minus className="h-4 w-4" /></Button>
                            <span className="w-5 text-center text-sm font-semibold">{q}</span>
                            <Button size="icon" className="h-8 w-8" onClick={() => cart.setQty(it.id, q + 1)} aria-label="Add one"><Plus className="h-4 w-4" /></Button>
                          </div>
                        ))}
                      </div>
                    );
                  })}
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <footer className="border-t border-border/50 py-10 text-center text-sm text-muted-foreground">
        <p className="font-display tracking-[0.2em] text-primary">DENMARK RESTAURANT</p>
        <p className="mt-1">Authentic Arabian & Chinese non-veg · Tamil Nadu</p>
        <Link to="/admin" className="mt-4 inline-block text-xs opacity-50 hover:opacity-100">Owner login</Link>
      </footer>

      {cart.count > 0 && !open && (
        <div className="fixed inset-x-0 bottom-4 z-40 flex justify-center px-4">
          <Button size="lg" className="shadow-glow w-full max-w-md justify-between" onClick={() => setOpen(true)}>
            <span>{cart.count} item{cart.count > 1 ? "s" : ""}</span><span>Checkout · {inr(cart.total)}</span>
          </Button>
        </div>
      )}

      <CheckoutSheet open={open} onOpenChange={setOpen} />
    </div>
  );
}

function slug(s: string) {
  return s.toLowerCase().replace(/[^a-z0-9]+/g, "-");
}

function CheckoutSheet({ open, onOpenChange }: { open: boolean; onOpenChange: (o: boolean) => void }) {
  const cart = useCart();
  const [type, setType] = useState<"dine_in" | "delivery" | null>(null);
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [address, setAddress] = useState("");
  const [notes, setNotes] = useState("");
  const [busy, setBusy] = useState(false);
  const [placed, setPlaced] = useState<number | null>(null);

  async function placeOrder() {
    if (!type) { toast.error("Choose Dine In or Delivery"); return; }
    if (!name.trim() || phone.trim().length < 6) { toast.error("Enter your name and phone number"); return; }
    if (type === "delivery" && !address.trim()) { toast.error("Enter your delivery address"); return; }
    setBusy(true);
    const id = crypto.randomUUID();
    const { error } = await supabase.from("orders").insert({
      id,
      customer_name: name.trim(),
      phone: phone.trim(),
      address: type === "delivery" ? address.trim() : null,
      notes: notes.trim() || null,
      order_type: type,
      items: cart.lines.map((l) => ({ id: l.id, qty: l.qty })),
    });
    setBusy(false);
    if (error) { toast.error("Could not place order. Please try again."); return; }
    setPlaced(1);
    cart.clear();
    toast.success("Order sent to the restaurant!");
  }

  return (
    <Sheet open={open} onOpenChange={(o) => { onOpenChange(o); if (!o) setPlaced(null); }}>
      <SheetContent className="flex w-full flex-col overflow-y-auto sm:max-w-md">
        <SheetHeader><SheetTitle className="font-display text-2xl">Your order</SheetTitle></SheetHeader>

        {placed ? (
          <div className="flex flex-1 flex-col items-center justify-center gap-3 text-center">
            <div className="text-5xl">🍗</div>
            <h3 className="font-display text-2xl">Thank you, {name.split(" ")[0]}!</h3>
            <p className="text-muted-foreground">Your order has reached Denmark Restaurant. We'll call you on {phone} to confirm.</p>
            <Button onClick={() => onOpenChange(false)}>Back to menu</Button>
          </div>
        ) : cart.lines.length === 0 ? (
          <p className="py-10 text-center text-muted-foreground">Your cart is empty.</p>
        ) : (
          <div className="flex flex-1 flex-col gap-5 px-4 pb-6">
            <div className="space-y-2">
              {cart.lines.map((l) => (
                <div key={l.id} className="flex items-center justify-between gap-2 text-sm">
                  <span className="flex-1">{l.name}</span>
                  <div className="flex items-center gap-1">
                    <Button size="icon" variant="ghost" className="h-7 w-7" onClick={() => cart.setQty(l.id, l.qty - 1)}><Minus className="h-3 w-3" /></Button>
                    <span className="w-4 text-center">{l.qty}</span>
                    <Button size="icon" variant="ghost" className="h-7 w-7" onClick={() => cart.setQty(l.id, l.qty + 1)}><Plus className="h-3 w-3" /></Button>
                  </div>
                  <span className="w-16 text-right">{inr(l.price * l.qty)}</span>
                </div>
              ))}
              <div className="flex justify-between border-t border-border pt-3 font-semibold">
                <span>Total</span><span className="text-primary">{inr(cart.total)}</span>
              </div>
            </div>

            <div className="space-y-3">
              <div><Label htmlFor="n">Name</Label><Input id="n" value={name} maxLength={100} onChange={(e) => setName(e.target.value)} /></div>
              <div><Label htmlFor="p">Phone</Label><Input id="p" type="tel" value={phone} maxLength={20} onChange={(e) => setPhone(e.target.value)} /></div>
              <div><Label htmlFor="no">Notes (optional)</Label><Textarea id="no" value={notes} maxLength={500} onChange={(e) => setNotes(e.target.value)} placeholder="Less spicy, extra mayo…" /></div>
            </div>

            <div>
              <p className="mb-2 text-sm font-medium">How would you like your order?</p>
              <div className="grid grid-cols-2 gap-3">
                {([["dine_in", "DINE IN", UtensilsCrossed], ["delivery", "DELIVERY", Bike]] as const).map(([v, label, Icon]) => (
                  <button key={v} type="button" onClick={() => setType(v)}
                    className={`flex flex-col items-center gap-2 rounded-lg border-2 p-4 font-display tracking-wider transition ${type === v ? "border-primary bg-primary/10 text-primary" : "border-border text-muted-foreground hover:border-primary/50"}`}>
                    <Icon className="h-6 w-6" />{label}
                  </button>
                ))}
              </div>
            </div>

            {type === "delivery" && (
              <div><Label htmlFor="a">Delivery address</Label><Textarea id="a" value={address} maxLength={500} onChange={(e) => setAddress(e.target.value)} /></div>
            )}

            <Button size="lg" className="shadow-glow mt-auto" disabled={busy} onClick={placeOrder}>
              {busy ? "Placing order…" : `Place order · ${inr(cart.total)}`}
            </Button>
          </div>
        )}
      </SheetContent>
    </Sheet>
  );
}
