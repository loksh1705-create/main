import { createFileRoute, Link } from "@tanstack/react-router";
import { useCallback, useEffect, useRef, useState } from "react";
import { toast } from "sonner";
import { Bell, LogOut, Trash2, Plus, UtensilsCrossed, Bike } from "lucide-react";
import type { Session } from "@supabase/supabase-js";
import { supabase } from "@/integrations/supabase/client";
import type { Tables } from "@/integrations/supabase/types";
import { inr } from "@/lib/cart";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

export const Route = createFileRoute("/admin")({
  ssr: false,
  head: () => ({
    meta: [
      { title: "Owner Dashboard — Denmark Restaurant" },
      { name: "description", content: "Manage live orders and the menu for Denmark Restaurant." },
      { property: "og:title", content: "Owner Dashboard — Denmark Restaurant" },
      { property: "og:description", content: "Live orders and menu management." },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: AdminPage,
});

function AdminPage() {
  const [session, setSession] = useState<Session | null | undefined>(undefined);
  const [isAdmin, setIsAdmin] = useState<boolean | null>(null);

  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => setSession(data.session));
    const { data } = supabase.auth.onAuthStateChange((_e, s) => setSession(s));
    return () => data.subscription.unsubscribe();
  }, []);

  useEffect(() => {
    if (!session) { setIsAdmin(null); return; }
    supabase.rpc("has_role", { _user_id: session.user.id, _role: "admin" }).then(({ data }) => setIsAdmin(!!data));
  }, [session]);

  if (session === undefined) return <Center>Loading…</Center>;
  if (!session) return <LoginForm />;
  if (isAdmin === null) return <Center>Checking access…</Center>;
  if (!isAdmin)
    return (
      <Center>
        <p>This account is not the restaurant owner.</p>
        <Button variant="outline" onClick={() => supabase.auth.signOut()}>Sign out</Button>
      </Center>
    );
  return <Dashboard email={session.user.email ?? ""} />;
}

function Center({ children }: { children: React.ReactNode }) {
  return <div className="flex min-h-screen flex-col items-center justify-center gap-4 px-4 text-center">{children}</div>;
}

function LoginForm() {
  const [mode, setMode] = useState<"in" | "up">("in");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    if (mode === "in") {
      const { error } = await supabase.auth.signInWithPassword({ email, password });
      if (error) toast.error(error.message);
    } else {
      const { data, error } = await supabase.auth.signUp({
        email, password, options: { emailRedirectTo: `${window.location.origin}/admin` },
      });
      if (error) toast.error(error.message);
      else if (!data.session) toast.success("Check your email to confirm your account.");
    }
    setBusy(false);
  }

  return (
    <Center>
      <h1 className="font-display text-3xl tracking-[0.15em] text-primary">DENMARK</h1>
      <p className="text-muted-foreground">Owner {mode === "in" ? "sign in" : "registration"}</p>
      <form onSubmit={submit} className="w-full max-w-sm space-y-3 text-left">
        <div><Label htmlFor="e">Email</Label><Input id="e" type="email" required value={email} onChange={(e) => setEmail(e.target.value)} /></div>
        <div><Label htmlFor="pw">Password</Label><Input id="pw" type="password" required minLength={6} value={password} onChange={(e) => setPassword(e.target.value)} /></div>
        <Button className="w-full" disabled={busy}>{mode === "in" ? "Sign in" : "Create owner account"}</Button>
      </form>
      <button className="text-sm text-muted-foreground underline" onClick={() => setMode(mode === "in" ? "up" : "in")}>
        {mode === "in" ? "First time? Create the owner account" : "Already registered? Sign in"}
      </button>
      <Link to="/" className="text-xs text-muted-foreground">← Back to menu</Link>
    </Center>
  );
}

type Order = Tables<"orders">;
type Item = Tables<"menu_items">;
type OrderLine = { name: string; qty: number; price: number };

function beep() {
  try {
    const ctx = new AudioContext();
    [0, 0.25, 0.5].forEach((t) => {
      const o = ctx.createOscillator(); const g = ctx.createGain();
      o.frequency.value = 880; o.connect(g); g.connect(ctx.destination);
      g.gain.setValueAtTime(0.3, ctx.currentTime + t);
      g.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + t + 0.2);
      o.start(ctx.currentTime + t); o.stop(ctx.currentTime + t + 0.2);
    });
  } catch {}
}

function Dashboard({ email }: { email: string }) {
  const [orders, setOrders] = useState<Order[]>([]);
  const loadOrders = useCallback(async () => {
    const { data } = await supabase.from("orders").select("*").order("created_at", { ascending: false }).limit(200);
    setOrders(data ?? []);
  }, []);

  useEffect(() => {
    loadOrders();
    if ("Notification" in window && Notification.permission === "default") Notification.requestPermission();
    const ch = supabase
      .channel("orders-live")
      .on("postgres_changes", { event: "INSERT", schema: "public", table: "orders" }, (p) => {
        const o = p.new as Order;
        setOrders((prev) => [o, ...prev.filter((x) => x.id !== o.id)]);
        beep();
        const label = o.order_type === "delivery" ? "DELIVERY" : "DINE IN";
        toast.success(`New ${label} order #${o.order_number} from ${o.customer_name} · ${inr(o.total)}`, { duration: 10000 });
        if ("Notification" in window && Notification.permission === "granted")
          new Notification("New order — Denmark Restaurant", { body: `${label} · ${o.customer_name} · ${inr(o.total)}` });
      })
      .on("postgres_changes", { event: "UPDATE", schema: "public", table: "orders" }, (p) => {
        const o = p.new as Order;
        setOrders((prev) => prev.map((x) => (x.id === o.id ? o : x)));
      })
      .subscribe();
    return () => { supabase.removeChannel(ch); };
  }, [loadOrders]);

  const newCount = orders.filter((o) => o.status === "new").length;

  return (
    <div className="mx-auto min-h-screen max-w-6xl px-4 py-8">
      <div className="mb-6 flex items-center justify-between gap-4">
        <div>
          <h1 className="font-display text-3xl text-primary">Owner Dashboard</h1>
          <p className="text-sm text-muted-foreground">{email}</p>
        </div>
        <div className="flex items-center gap-2">
          <span className="flex items-center gap-1 rounded-full bg-primary/15 px-3 py-1 text-sm text-primary"><Bell className="h-4 w-4" />{newCount} new</span>
          <Button variant="outline" size="sm" onClick={() => supabase.auth.signOut()}><LogOut className="h-4 w-4" /></Button>
        </div>
      </div>
      <p className="mb-6 rounded-lg border border-border bg-card p-3 text-sm text-muted-foreground">
        Keep this page open — new orders appear instantly with a sound and a notification.
      </p>
      <Tabs defaultValue="orders">
        <TabsList><TabsTrigger value="orders">Orders</TabsTrigger><TabsTrigger value="menu">Menu</TabsTrigger></TabsList>
        <TabsContent value="orders"><OrdersList orders={orders} /></TabsContent>
        <TabsContent value="menu"><MenuEditor /></TabsContent>
      </Tabs>
    </div>
  );
}

const STATUSES = ["new", "preparing", "completed", "cancelled"] as const;

function OrdersList({ orders }: { orders: Order[] }) {
  async function setStatus(id: string, status: string) {
    const { error } = await supabase.from("orders").update({ status }).eq("id", id);
    if (error) toast.error(error.message);
  }
  if (!orders.length) return <p className="py-10 text-center text-muted-foreground">No orders yet.</p>;
  return (
    <div className="grid gap-4 md:grid-cols-2">
      {orders.map((o) => {
        const lines = (o.items as unknown as OrderLine[]) ?? [];
        return (
          <div key={o.id} className={`rounded-lg border bg-card p-4 ${o.status === "new" ? "border-primary" : "border-border"}`}>
            <div className="flex items-start justify-between gap-2">
              <div>
                <p className="font-semibold">#{o.order_number} · {o.customer_name}</p>
                <a href={`tel:${o.phone}`} className="text-sm text-primary">{o.phone}</a>
                <p className="text-xs text-muted-foreground">{new Date(o.created_at).toLocaleString("en-IN")}</p>
              </div>
              <span className="flex items-center gap-1 rounded-md bg-secondary px-2 py-1 text-xs font-semibold tracking-wider">
                {o.order_type === "delivery" ? <><Bike className="h-3 w-3" />DELIVERY</> : <><UtensilsCrossed className="h-3 w-3" />DINE IN</>}
              </span>
            </div>
            {o.address && <p className="mt-2 text-sm"><span className="text-muted-foreground">Address:</span> {o.address}</p>}
            {o.notes && <p className="mt-1 text-sm"><span className="text-muted-foreground">Notes:</span> {o.notes}</p>}
            <ul className="mt-3 space-y-1 border-t border-border pt-3 text-sm">
              {lines.map((l, i) => <li key={i} className="flex justify-between"><span>{l.qty} × {l.name}</span><span>{inr(l.price * l.qty)}</span></li>)}
            </ul>
            <div className="mt-2 flex justify-between font-semibold"><span>Total</span><span className="text-primary">{inr(o.total)}</span></div>
            <div className="mt-3 flex flex-wrap gap-2">
              {STATUSES.map((s) => (
                <Button key={s} size="sm" variant={o.status === s ? "default" : "outline"} onClick={() => setStatus(o.id, s)} className="capitalize">{s}</Button>
              ))}
            </div>
          </div>
        );
      })}
    </div>
  );
}

function MenuEditor() {
  const [items, setItems] = useState<Item[]>([]);
  const [draft, setDraft] = useState({ name: "", category: "", price: "" });
  const load = useCallback(async () => {
    const { data } = await supabase.from("menu_items").select("*").order("category").order("sort_order");
    setItems(data ?? []);
  }, []);
  useEffect(() => { load(); }, [load]);

  const timers = useRef<Record<string, ReturnType<typeof setTimeout>>>({});
  function patch(id: string, changes: Partial<Item>) {
    setItems((prev) => prev.map((i) => (i.id === id ? { ...i, ...changes } : i)));
    clearTimeout(timers.current[id]);
    timers.current[id] = setTimeout(async () => {
      const { error } = await supabase.from("menu_items").update(changes).eq("id", id);
      if (error) toast.error(error.message); else toast.success("Saved");
    }, 600);
  }
  async function remove(id: string) {
    if (!confirm("Delete this dish?")) return;
    const { error } = await supabase.from("menu_items").delete().eq("id", id);
    if (error) toast.error(error.message); else setItems((p) => p.filter((i) => i.id !== id));
  }
  async function add(): Promise<void> {
    const price = Number(draft.price);
    if (!draft.name.trim() || !draft.category.trim() || !(price >= 0)) { toast.error("Fill name, category and price"); return; }
    const { error } = await supabase.from("menu_items").insert({ name: draft.name.trim(), category: draft.category.trim(), price, sort_order: 999 });
    if (error) { toast.error(error.message); return; }
    setDraft({ name: "", category: "", price: "" });
    load();
  }

  const categories = [...new Set(items.map((i) => i.category))];

  return (
    <div className="space-y-6">
      <div className="grid gap-2 rounded-lg border border-border bg-card p-4 sm:grid-cols-[2fr_2fr_1fr_auto]">
        <Input placeholder="Dish name" value={draft.name} onChange={(e) => setDraft({ ...draft, name: e.target.value })} />
        <Input placeholder="Category" list="cats" value={draft.category} onChange={(e) => setDraft({ ...draft, category: e.target.value })} />
        <datalist id="cats">{categories.map((c) => <option key={c} value={c} />)}</datalist>
        <Input placeholder="Price ₹" type="number" min={0} value={draft.price} onChange={(e) => setDraft({ ...draft, price: e.target.value })} />
        <Button onClick={add}><Plus className="h-4 w-4" />Add dish</Button>
      </div>
      {categories.map((cat) => (
        <div key={cat}>
          <h3 className="mb-2 font-display text-xl text-primary">{cat}</h3>
          <div className="divide-y divide-border rounded-lg border border-border bg-card">
            {items.filter((i) => i.category === cat).map((i) => (
              <div key={i.id} className="flex flex-wrap items-center gap-2 p-2">
                <Input className="min-w-40 flex-1" value={i.name} onChange={(e) => patch(i.id, { name: e.target.value })} />
                <Input className="w-28" type="number" min={0} value={i.price} onChange={(e) => patch(i.id, { price: Number(e.target.value) })} />
                <label className="flex items-center gap-2 text-xs text-muted-foreground">
                  <Switch checked={i.available} onCheckedChange={(v) => patch(i.id, { available: v })} />Available
                </label>
                <Button size="icon" variant="ghost" onClick={() => remove(i.id)} aria-label="Delete"><Trash2 className="h-4 w-4" /></Button>
              </div>
            ))}
          </div>
        </div>
      ))}
    </div>
  );
}
